# MezX Website — V6

## Included
- `index.html` — responsive main website, product explorer, sample dashboard demo, contact composer and atomic orbital interface
- `products/mai.html`, `products/mci.html`, `products/mfi.html`, `products/mfs.html` — individual product direction pages
- `about.html` — company overview
- `architecture.html` — conceptual architecture explainer
- `website-data-note.html` — current static-site data handling note

## Orbital interaction
Four orbital planes can each be dragged independently. The fourth MFS ring is gold. Drag open space to rotate the complete structure together. Use the on-screen All rings / Ring 01 / Ring 02 / Ring 03 / Ring 04 controls to choose a control target, the reset button to restore the default arrangement, and arrow keys for master movement. The model uses inertial easing and respects reduced-motion preferences.

## Dashboard prototype
The Overview, Trend and Breakdown controls update the illustrative sample dashboard. All values are fictional and are not customer or business results.

## Contact form
The form validates required fields in the browser and opens the visitor's email application with a prepared message. It does not transmit or store form submissions on a MezX server.

## Deploy
Upload the complete folder contents to a GitHub repository. Enable GitHub Pages from the `main` branch and root folder. Preserve the `products/` directory and relative paths. No build step is required.

## Accuracy
MezX is described as an early-stage venture. MAI/MCI/MFI/MFS are proposed product pillars; architecture is conceptual; dashboard data is illustrative. Do not claim live products, integrations, clients, certifications, registrations or outcomes unless independently verified.

Contact: mezx.global@proton.me · https://www.linkedin.com/company/mezx

## MFS standards scope
The MFS concept page documents IFRS, jurisdiction-specific GAAP, IFRS S1/S2 (ISSB), ISA, Basel III and the evolving Basel framework (often called Basel IV), FATF 40 Recommendations, IOSCO Objectives and Principles, G20/OECD Principles of Corporate Governance, and selected World Bank/UNCITRAL materials. It also describes configurable local taxation, VAT/GST, customs and sector rule packs. These are distinct framework families, not interchangeable accounting standards.

## Interaction update
Selecting any orbital product button now scrolls to the product explorer on desktop and mobile. The product panel receives focus after the scroll for keyboard accessibility.
